<?php

/** * Runs on plugin activation */

require_once __DIR__ . '/installer/installer.php';
