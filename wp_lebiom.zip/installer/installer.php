<?php

global $wpdb;

