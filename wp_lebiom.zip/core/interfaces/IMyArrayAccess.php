<?php

namespace boctulus\SW\core\interfaces;

interface IMyArrayAccess {
    // methods

}