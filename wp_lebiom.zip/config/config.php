<?php

return [
    
    // No editar desde aqui -->

    'debug'             => env('DEBUG'),  

    'front_controller'  => true,

    'router'            => true,

    'namespace'         => "boctulus\SW",

	'use_composer'      => true,
];

